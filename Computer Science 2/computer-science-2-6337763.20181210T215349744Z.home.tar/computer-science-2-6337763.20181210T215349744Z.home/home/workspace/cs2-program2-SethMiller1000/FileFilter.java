import java.util.*;
import java.io.*;

public class FileFilter
{
  public static void main( String [] args ) throws FileNotFoundException, NoSuchElementException
  {
    Scanner scan = new Scanner( System.in );

    System.out.print( "Name the file you want to filter: " );
    String input = scan.next();
    System.out.println();

    LinkedQueue<Character> queue = new LinkedQueue<Character>();
    File file = new File( "answer.txt" );
    PrintWriter pw = new PrintWriter( file );

    try
    {
      Scanner fileScan = new Scanner( new File( input ) );

      while ( fileScan.hasNext() )
      {
        String line = fileScan.nextLine();
        boolean tag = false;

        for ( int i = 0; i < line.length(); i++ )
        {
          char c = line.charAt( i );

          if ( c == '<' )
          {
            tag = true;

          }// end of if if ( c == '<' )

          else if ( c == '>' )
          {
            tag = false;

          }// end of else if ( c == '>' )

          if ( ( ( c == '\'') || ( ( c >= 'A' ) && ( c <= 'Z' ) ) || ( ( c >= 'a' ) && ( c <= 'z' ) ) || ( ( c >= '0' ) && ( c <= '9' ) ) ) && ( !tag ) )
          {
            queue.enqueue( c );

          }// end of if c is a letter of the alphabet or apostrophe

          else if ( !( queue.isEmpty() ) )
          {
            pw.println( queue );
            System.out.println( queue );

            while ( !( queue.isEmpty() ) )
            {
              queue.dequeue();

            }// end of while ( !( queue.isEmpty() ) )

          }// end of else if ( !( queue.isEmpty() ) )

        }// end of for ( int i = 0; i < line.length(); i++ )

        if ( !( queue.isEmpty() ) )
        {
          pw.println( queue );
          System.out.println( queue );

          while ( !( queue.isEmpty() ) )
          {
            queue.dequeue();

          }// end of while ( !( queue.isEmpty() ) )

        }// end of if ( !( queue.isEmpty() ) )

      }// end of while ( fileScan.hasNext() )

    }// end of try

    catch ( FileNotFoundException e )
    {
      System.out.println( "Error: The file does not exist." );
      System.out.println();

    }// end of catch ( FileNotFoundException e )

    catch ( NoSuchElementException e )
    {
      System.out.println( "Error: The element does not exist." );
      System.out.println();

    }// end of catch ( NoSuchElementException)

    pw.close();

  }// end of main

}// end of FileFilter
