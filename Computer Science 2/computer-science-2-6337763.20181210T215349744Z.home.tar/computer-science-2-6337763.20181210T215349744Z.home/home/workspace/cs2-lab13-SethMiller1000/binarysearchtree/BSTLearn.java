package binarysearchtree;

public class BSTLearn
{
  public static void main( String [] args )
  {
    // Create the empty tree
    BinSrchTree tree = new BinSrchTree();

    String keys = "ABCDEFGHIJ";

    for ( char key: keys.toCharArray() )
    {
      System.out.println( "Inserting: " + key );
      tree.insert( "" + key, "" + key );
      System.out.println( "The height is: " + tree.depth() );

      tree.prettyPrintTree();
      System.out.println();

    }// end of for ( char key: keys.toCharArray() )

    // Display the tree
    System.out.println( "Finished result:" );
    tree.prettyPrintTree();
    System.out.println();

    tree = new BinSrchTree();
    keys = "KAODHJ";

    for ( char key: keys.toCharArray() )
    {
      System.out.println( "Inserting: " + key );
      tree.insert( "" + key, "" + key );
      System.out.println( "The height is: " + tree.depth() );

      tree.prettyPrintTree();
      System.out.println();

    }// end of for ( char key: keys.toCharArray() ) #2

    //Display the tree
    System.out.println( "Finished result:" );
    tree.prettyPrintTree();
    System.out.println();

    // test element removal
    tree.insert( "P", "P" );
    tree.prettyPrintTree();
    System.out.println();

    tree.delete( "J" );
    tree.prettyPrintTree();
    System.out.println();

    tree.delete( "A" );
    tree.prettyPrintTree();
    System.out.println();

    tree.delete( "D" );
    tree.prettyPrintTree();
    System.out.println();

    tree.delete( "H" );
    tree.prettyPrintTree();
    System.out.println();

    System.out.println( "The height is: " + tree.depth() );

  }// end of main

}// end of BSTLearn class
