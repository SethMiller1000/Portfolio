package binarysearchtree;

public class BSTNode
{
  protected String key;
  protected Object element;
  protected BSTNode left, right;
  protected int height;

  public BSTNode( String key, Object element, BSTNode left, BSTNode right )
  {
    this.key = key;
    this.element = element;
    this.left = left;
    this.right = right;
    height = 0;

  }// end of BSTNode constructor

  public int getHeight()
  {
    return height;

  }// end of getHeight

  public void setHeight( int height )
  {
    this.height = height;

  }// end of setHeight

  public String getKey()
  {
    return key;

  }// end of getKey

  public Object getElement()
  {
    return element;

  }// end of getElement

  public BSTNode getLeft()
  {
    return left;

  }// end of getLeft

  public BSTNode getRight()
  {
    return right;

  }// end of getRight

  public void setElement( Object element )
  {
    this.element = element;

  }// end of setElement

  public void setLeft( BSTNode node )
  {
    left = node;

  }// end of setLeft

  public void setRight( BSTNode node )
  {
    right = node;

  }// end of setRight

  public void print()
  {
    if ( right != null ) {
      right.recPrint( true, "" );
    }

    System.out.println( key );

    if ( left != null ) {
      left.recPrint( false, "" );
    }

  }// end of print

  private void recPrint( boolean isRight, String indent )
  {
    if ( right != null ) {
      right.recPrint( true, indent + ( isRight ? "        " : " |      " ) );
    }

    System.out.print( indent );

    if ( isRight ) {
      System.out.print( " /" );
    } else {
      System.out.print( " \\" );
    }

    System.out.println( "----- " + key );

    if ( left != null ) {
      left.recPrint( false, indent + ( isRight ? " |      " : "        " ) );
    }
  }// end of recPrint

}// end of BSTNode class