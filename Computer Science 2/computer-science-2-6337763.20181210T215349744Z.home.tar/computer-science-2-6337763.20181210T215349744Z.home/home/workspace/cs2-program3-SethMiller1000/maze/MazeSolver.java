package maze;
import java.io.FileNotFoundException;

public class MazeSolver
{
  private Maze maze;
  private Agenda<Square> agenda;

  public static void main( String [] args ) throws FileNotFoundException
  {
    String fileName = args[0];
    Maze maze = new Maze( fileName );
    Agenda<Square> agenda = new MyStack<Square>(); // Change this to queue to compare the results.
    MazeSolver solver = new MazeSolver( maze, agenda );
    boolean success = solver.solve();
    if( success == true ) {
      System.out.println("This maze is solved:");
      System.out.println( maze );
    } else {
      System.out.println("This maze is not solvable:");
      System.out.println( maze );
    }

  }// end of main

  public MazeSolver( Maze maze, Agenda<Square> agenda )
  {
    this.maze = maze;
    this.agenda = agenda;

  }// end of public MazeSolver (constructor)

  // return true if maze is solved, otherwise return false;
  public boolean solve()
  {
    addNeighbors( maze.getStart() );

    while ( !agenda.isEmpty() )
    {
      Square currentSquare = agenda.remove();

      if ( currentSquare.getType() == SquareType.FINISH )
      {
        return true;

      }// end of if ( currentSquare.getType() == FINISH )

      else if ( currentSquare.getType() == SquareType.SPACE )
      {
        addNeighbors( currentSquare );
        currentSquare.markTried();

      }// end of else if ( currentSquare.getType() == SPACE )

    }// end of while ( !agenda.isEmpty() )

    return false;

  }// end of public boolean solve()

  // add neighbors of a square to the agenda
  private void addNeighbors( Square s )
  {
    int row = s.getRow();
    int col = s.getCol();

    // neighbor to the north
    Square neighbor = maze.getSquare( row + 1, col );
    if ( neighbor != null && neighbor.getType() != SquareType.WALL && neighbor.getType() != SquareType.TRIED ) {
      agenda.add( neighbor );
    }
    // neighbor to the south
    neighbor = maze.getSquare( row - 1, col );
    if ( neighbor != null && neighbor.getType() != SquareType.WALL && neighbor.getType() != SquareType.TRIED ) {
      agenda.add( neighbor );
    }
    // neighbor to the east
    neighbor = maze.getSquare( row, col + 1 );
    if ( neighbor != null && neighbor.getType() != SquareType.WALL && neighbor.getType() != SquareType.TRIED ) {
      agenda.add( neighbor );
    }
    // neighbor to the west
    neighbor = maze.getSquare( row, col - 1 );
    if ( neighbor != null && neighbor.getType() != SquareType.WALL && neighbor.getType() != SquareType.TRIED ) {
      agenda.add( neighbor );
    }

  }// end of private void addNeighbors

}// end of public class MazeSolver