public class InvalidMazeException extends RuntimeException{
}
