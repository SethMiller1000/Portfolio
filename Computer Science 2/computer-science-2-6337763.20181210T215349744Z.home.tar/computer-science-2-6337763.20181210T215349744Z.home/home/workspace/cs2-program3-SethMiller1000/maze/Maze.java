package maze;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Maze
{
  private int rows;
  private int cols;
  private Square start;
  private Square[][] grid;

  public Maze(String fileName) throws FileNotFoundException
  {
    Scanner scan = new Scanner(new File(fileName));
    cols = Integer.parseInt(scan.next()); // number of columns is first in file
    rows = Integer.parseInt(scan.next()); // number of rows is second in file

    grid = new Square[rows][cols];

    // remove line break;
    scan.nextLine();

    // read maze configuration
    for( int i = 0; i < rows; i++ )
    {
      String row = scan.nextLine();

      for( int j = 0; j < cols; j++ )
      {
        // create a square from the char representation
        // remember the square as "start" if it is the starting point


        SquareType type = SquareType.fromChar( row.charAt( j ) );
        Square thisSquare = new Square( type, i, j );
        grid[i][j] = thisSquare;

        // remember the square as "start" if it is the starting point
        if ( type == SquareType.START )
        {
          start = thisSquare;

        }// end of if ( type == SquareType.START )

        //System.out.print(row.charAt(j));

      }// end of for( int j = 0; j < cols; j++ )

      //System.out.println();

    }// end of for( int i = 0; i < rows; i++ )

  }// end of public Maze(String fileName) throws FileNotFoundException

  public int getRows(){
    return rows;
  }

  public int getColumns(){
    return cols;
  }

  public Square getStart(){
    return start;
  }

  // return null if the location is out of bounds.
  public Square getSquare( int row, int col )
  {
    if(row < 0 || row >= rows || col < 0 || col >= cols) {
      return null;
    } else {
      return grid[row][col];
    }
  }// end of public Square getSquare( int row, int col )

  public String toString()
  {
    String result = "";
    for( int i = 0; i < rows; i++ )
    {
      for( int j = 0; j < cols; j++ )
      {
        result += grid[i][j];
      }
      result += "\n";
    }
    return result;

  }// end of public String toString()

}// end of public class Maze