import java.util.*;
import java.io.*;

public class FileScanner
{
  public static void main( String [] args ) throws FileNotFoundException
  {
    String line="";

    try
    {
      Scanner scan = new Scanner( new File ( "simple.html" ) );

      while( scan.hasNext() )// while there are more lines to read
      {
        line = scan.nextLine();   // read one in
        System.out.println( line );   // and print it back out

      }// end of while ( scan.hasNext() )

    }// end of try

    catch( FileNotFoundException e)
    {
      System.out.println( "Error: file does not exist." );

    }// end of catch

  }// end of main

}// end of FileScanner