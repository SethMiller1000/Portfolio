package heap;

import java.io.*;

public class HeapTest
{
  public static void main( String [] args )
  {
    //Create the heap
    Heap h = new Heap();

    //Insert some items
    h.insert( new Integer( 4 ), 4 );
    h.insert( new Integer( 7 ), 7 );
    h.insert( new Integer( 3 ), 3 );
    h.insert( new Integer( 8 ), 8 );
    h.insert( new Integer( 9 ), 9 );
    h.insert( new Integer( 6 ), 6 );
    h.insert( new Integer( 5 ), 5 );
    // old items: 5,3,7,1,6,2,10
    // new items: 4,7,3,8,9,6,5

    System.out.println( "Here is the heap: "+ h );
    System.out.println();
    System.out.println( "getting ready to deplete the tree" );
    System.out.println();

    while ( !h.isEmpty() )
    {
      Object element = h.remove();
      System.out.println( "Here is the heap: " + h );
      System.out.println( "Removed: " + element );
      System.out.println();

    }// end of while ( !h.isEmpty() )

  }// end of main

}// end of HeapTest
