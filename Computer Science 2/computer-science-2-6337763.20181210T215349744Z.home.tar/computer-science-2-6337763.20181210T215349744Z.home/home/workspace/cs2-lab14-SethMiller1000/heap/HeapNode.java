package heap;

public class HeapNode
{
  protected Object element; // The entry's data.
  protected int priority; // The entry's priority.

  public HeapNode ()
  {
    element = null;
    priority = 100;

  }// end of HeapNode constructor with no parameters

  public HeapNode ( Object element, int priority )
  {
    this.element = element;
    this.priority = priority;

  }// end of HeapNode constructors with parameters

  public Object getElement ()
  {
    return element;

  }// end of getElement

  public int getPriority ()
  {
    return priority;

  }// end of getPriority

  public void setElement ( Object newElement )
  {
    element = newElement;

  }// end of setElement

  public void setPriority ( int newPriority )
  {
    priority = newPriority;

  }// end of setPriority

}// end of HeapNode