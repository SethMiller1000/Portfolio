package maze;

public class Square implements Comparable<Square>
{
  private SquareType type;
  private int row;
  private int col;
  private int distance;

  public Square( SquareType type, int row, int col )
  {
    this.type = type;
    this.row = row;
    this.col = col;

  }// end of Square constructor

  public SquareType getType()
  {
    return type;

  }// end of getType

  public void markTried()
  {
    type = SquareType.TRIED;

  }// end of markTried

  public int getRow()
  {
    return row;

  }// end of getRow

  public int getCol()
  {
    return col;

  }// end of getCol

  public void setDistance( int distance )
  {
    this.distance = distance;

  }// end of setDistance

  public int getDistance()
  {
    return distance;

  }// end of getDistance

  public int compareTo(Square other)
  {
    return other.distance - this.distance;

  }// end of compareTo

  public String toString()
  {
    return type.toString();

  }// end of toString

}// end of Square