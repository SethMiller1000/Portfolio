package maze;
import java.util.Stack;

/**
 * MyQueue is a FIFO queue that implements Agenda.
 */
public class MyStack<T> implements Agenda<T>
{
  private Stack<T> stack;

  public MyStack()
  {
    stack = new Stack<T>();

  }// end of MyStack constructor

  public boolean isEmpty()
  {
    return stack.isEmpty();

  }// end of isEmpty

  public int size()
  {
    return stack.size();

  }// end of size

  public void add( T newItem )
  {
    stack.push( newItem );

  }// end of add

  public T remove()
  {
    return stack.pop();

  }// end of remove

  public T peek()
  {
    return stack.peek();

  }// end of peek

}// end of MyStack