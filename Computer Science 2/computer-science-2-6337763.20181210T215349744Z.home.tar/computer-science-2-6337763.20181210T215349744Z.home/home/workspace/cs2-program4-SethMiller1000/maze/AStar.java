package maze;

public class AStar<T> implements Agenda<T>
{
  private Heap<T> h;

  public AStar()
  {
    h = new Heap<T>();

  }// end of AStar constructor

  public boolean isEmpty()
  {
    return h.isEmpty();

  }// end of isEmpty

  public int size()
  {
    return h.size();

  }// end of size

  public void add( T newItem )
  {
    h.insert( newItem );

  }// end of add

  public T remove()
  {
    return h.remove();

  }// end of remove

  public T peek()
  {
    return h.peek();

  }// end of peek

}// end of AStar