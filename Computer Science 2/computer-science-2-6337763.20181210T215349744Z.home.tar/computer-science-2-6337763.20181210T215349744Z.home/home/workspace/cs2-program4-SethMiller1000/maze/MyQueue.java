package maze;
import java.util.LinkedList;

public class MyQueue<T> implements Agenda<T>
{
  private LinkedList<T> queue;

  public MyQueue()
  {
    queue = new LinkedList<T>();

  }// end of MyQueue constructor

  public boolean isEmpty()
  {
    return queue.isEmpty();

  }// end of isEmpty

  public int size()
  {
    return queue.size();

  }// end of size

  public void add( T newItem )
  {
    queue.add( newItem );

  }// end of add

  public T remove()
  {
    return queue.removeFirst();

  }// end of remove

  public T peek()
  {
    return queue.peek();

  }// end of peek

}// end of MyQueue