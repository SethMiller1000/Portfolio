import java.util.*;
import java.io.*;

public class Maze
{
	//public static void moveToPosition( int row, int column );

	public static void main( String [] args ) throws FileNotFoundException, InterruptedException
	{
		System.out.println();

		Scanner scan = new Scanner( new File( "maze.txt" ) );
		int cols = Integer.parseInt( scan.next() );
		int rows = Integer.parseInt( scan.next() );
		String row = "";
		char[][] maze = new char[rows][cols];
		scan.nextLine();

		/* READING IN MAZE */
		for ( int x = 0; x < rows; x++ )
		{
			row = scan.nextLine();

			for ( int y = 0; y < cols; y++ )
			{
				maze[x][y] = row.charAt( y );

			}// end of for ( int y = 0; y < cols; y++ )

		}// end of for ( int x = 0; x < rows; x++ )

		int xPos = 1; // starting x position
		int yPos = 8; // starting y position

		/// ANIMATION ///
		for ( int i = 36; i > 0; i-- )
		{
			/* DISPLAYING MAZE */
			for ( int x = 0; x < rows; x++ )
			{
				for ( int y = 0; y < cols; y++ )
				{
					System.out.print(maze[x][y]);

				}// end of for ( int y = 0; y < cols; y++ )

				System.out.println();

			}// end of for ( int x = 0; x < rows; x++ )

			System.out.println( i );
			Thread.sleep( 1000 );
			System.out.print( "\033\143" );

			maze[yPos][xPos] = '.';

			// The following lines of code are location updates based on the Cartesian coordinate plane

			if ( xPos == 1 && ( yPos <= 8 && yPos >= 6 ) ) // MOVES 1 - 3
			{
				yPos--;

			}// END OF MOVES 1 - 3

			else if ( ( xPos == 1 || xPos == 2 ) && yPos == 5 ) // MOVES 4 - 5
			{
				xPos++;

			}// END OF MOVES 4 - 5

			else if ( xPos == 3 && ( yPos <= 7 && yPos >= 5 ) ) // MOVES 6 - 8
			{
				yPos++;

			}// END OF MOVES 6 - 8

			else if ( ( xPos <= 7 && xPos >= 3 ) && yPos == 8 ) // MOVES 9 - 13
			{
				xPos++;

			}// END OF MOVES 9 - 13

			else if ( xPos == 8 && ( yPos <= 8 && yPos >= 4 ) ) // MOVES 14 - 18
			{
				yPos--;

			}// END OF MOVES 14 - 18

			else if ( ( xPos == 8 || xPos == 9 ) && yPos == 3 ) // MOVES 19 - 20
			{
				xPos++;

			}// END OF MOVES 19 - 20

			else if ( xPos == 10 && ( yPos == 3 || yPos == 2 ) ) // MOVES 21 - 22
			{
				yPos--;

			}// END OF MOVES 21 - 22

			else if ( ( xPos <= 10 && xPos >= 4 ) && yPos == 1 ) // MOVES 23 - 29
			{
				xPos--;

			}// END OF MOVES 23 - 29

			else if ( xPos == 3 && ( yPos == 2 || yPos == 1 ) ) // MOVES 30 - 31
			{
				yPos++;

			}// END OF MOVES 30 - 31

			else if ( ( xPos <= 5 && xPos >= 3 ) && yPos == 3 ) // MOVES 32 - 34
			{
				xPos++;

			}// END OF MOVES 32 - 34

			else if ( xPos == 6 && yPos == 3 ) // MOVE 35
			{
				yPos++;

			}// END OF MOVE 35

			maze[yPos][xPos] = 'o';

		}// end of for ( int i = 23; i > 0; i-- )

	}// end of main

}// end of Maze