// This is a BST Tree implementing a recursive algorithm for
// search, insertion, deletion, printing, and determining maximum
// depth.
package binarysearchtree;

public class BinSrchTree
{
  private BSTNode root; // The root of the Binary Search Tree.

  //PRE: None
  //POS: tree == null
  //TAS: Initialize the Binary Search tree to null
  public BinSrchTree()
  {
    root = null;

  }// end of public BinSrchTree constructor

  //PRE: None
  //POS: None
  //TAS: return root being equal to null
  boolean isEmpty()
  {
    return root == null;

  }// end of boolean isEmpty()

  //PRE: init<key>
  //POS: none
  //TAS: Search the tree for object with key
  // if (object with this key is in the tree)
  // return a reference to the object
  // else
  // return a null reference
  public Object search( String key )
  {
    BSTNode node = recSearch( root, key );
    if( node == null ){
      return null;
    }else{
      return node.getElement();
    }

  }// end of public Object search()

  //PRE:
  //POS:
  //TAS: Currently, this method is stubbed; it is returning
  // null because it has to return something.
  private BSTNode recSearch( BSTNode node, String key )
  {
    if ( node == null )
      return null;

    else if ( key.compareTo( node.getKey() ) == 0 )
      return node;

    else if ( key.compareTo( node.getKey() ) < 0 )
      return recSearch( node.getLeft(), key );

    else
      return recSearch( node.getRight(), key );

  } // recSearch method

  //PRE: init <key>, init<element>
  //POS: exit <tree> <-- entry <tree> + element
  //TAS: insert the object with key into the tree
  public void insert( String key, Object element ){
    root = recInsert( root, key, element );
  }

  //PRE:
  //POS:
  //TAS:
  private BSTNode recInsert( BSTNode node, String key, Object element )
  {
    if( node == null ){
      node = new BSTNode( key, element, null, null );
    } else if( key.compareTo( node.getKey() ) == 0 ) {
      node.setElement( element );
    } else if( key.compareTo( node.getKey() ) < 0 ) {
      node.setLeft( recInsert( node.getLeft(), key, element ) );
    } else {
      node.setRight( recInsert( node.getRight(), key, element ) );
    }
    return node;

  }// end of private BSTNode recInsert

  //PRE:
  //POS:
  //TAS:
  public void delete( String key )
  {
    root = recDelete( root, key );

  }// end of public void delete

  //PRE:
  //POS:
  //TAS: Currently, this method is stubbed; it is returning
  // null because it has to return something.
  private BSTNode recDelete( BSTNode node, String key )
  {
    if ( node == null ) {
      System.out.println ("Unable to find node with key.");
      return null;
    } else if ( key.compareTo( node.key ) == 0 ) {
      node = remove( node );
    } else if ( key.compareTo( node.key ) < 0 ) {
      node.setLeft( recDelete( node.getLeft(), key ) );
    } else {
      node.setRight( recDelete( node.getRight(), key ) );
    }
    return node;

  }// private BSTNode recDelete

  //PRE:
  //POS:
  //TAS:
  private BSTNode remove( BSTNode node )
  {
    BSTNode here = node;

    if ( node.getLeft() == null && node.getRight() != null )
    {
      return node.getRight();

    }// end of if ( node.getLeft() == null && node.getRight() != null )

    else if ( node.getLeft() != null && node.getRight() == null )
    {
      return node.getLeft();

    }// end of else if ( node.getLeft() != null && node.getRight() == null )

    else
    {
      node = node.getRight();
      BSTNode temp = node;

      while ( temp.getLeft() != null ) {
        temp = temp.getLeft();
      }

      temp.setLeft( here.getLeft() );
      return node;

    }// end of else

  }// end of private BSTNode removes

  //PRE:
  //POS:
  //TAS:
  public void printTree ()
  {
    System.out.println( this.toString() );

  }// end of public void printTree

  public String toString()
  {
    return recToString( root );

  }// public String toString()

  //PRE:
  //POS:
  //TAS:
  private String recToString( BSTNode node )
  {
    if ( node == null ){
      return "";
    } else {
      return recToString( node.getLeft() ) + node.getKey() + recToString( node.getRight() );
    }

  }// end of private String recToString

  //PRE:
  //POS:
  //TAS:
  public int depth()
  {
    return recDepth( root );

  }// end of public int depth()

  //PRE:
  //POS:
  //TAS:
  protected int recDepth( BSTNode node )
  {
    if ( node == null )
    {
      return 0;
    } else {
      return 1 + Math.max( recDepth( node.getLeft() ), recDepth( node.getRight() ) );
    }

  }// end of protected int recDepth

}// end of public class BinSrchTree