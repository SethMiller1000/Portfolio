package binarysearchtree;

public class BSTNode
{
  protected String key;
  protected Object element;
  protected BSTNode left, right;

  public BSTNode ( String key, Object element, BSTNode left, BSTNode right )
  {
    this.key = key;
    this.element = element;
    this.left = left;
    this.right = right;

  } // end of BSTNode constructor

  public String getKey ()
  {
    return key;

  } // end of getKey method

  public Object getElement ()
  {
    return element;

  } // end of getElement method

  public BSTNode getLeft ()
  {
    return left;

  } // end of getLeft method

  public BSTNode getRight ()
  {
    return right;

  } // end of getRight method

  public void setElement ( Object element )
  {
    this.element = element;

  } // end of setElement method

  public void setLeft ( BSTNode node )
  {
    left = node;

  } // end of setLeft method

  public void setRight ( BSTNode node )
  {
    right = node;

  } // end of setRight method

} /* end of BSTNode class */