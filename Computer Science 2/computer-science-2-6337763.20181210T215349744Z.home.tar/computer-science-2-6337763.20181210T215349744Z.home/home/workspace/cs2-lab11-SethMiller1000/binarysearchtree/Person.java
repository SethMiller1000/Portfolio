package binarysearchtree;

class Person
{
  protected String name;
  protected int age;

  public Person ( String name, int age )
  {
    this.name = name;
    this.age = age;

  } // end of Person constructor

  public int compareTo( Person other )
  {
    return name.compareTo( other.name );

  } // end of compareTo method

  public String getName ()
  {
    return name;

  } // end of toString method

  public int getAge ()
  {
    return age;

  } // end of getAge method

} /* end of Person class */