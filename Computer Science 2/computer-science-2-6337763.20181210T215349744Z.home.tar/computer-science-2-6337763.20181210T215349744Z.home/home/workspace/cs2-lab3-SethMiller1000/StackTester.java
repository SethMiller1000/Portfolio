public class StackTester
{
  public static void main (String [] args)
  {
    LinkedStack<Character> ls = new LinkedStack<Character>();

    ls.push (new Character ('a'));
    ls.push (new Character ('b'));
    ls.push (new Character ('c'));
    System.out.println(ls);

    if ( !( ls.isEmpty() ) )
    {
      ls.pop();
    }

    else
    {
      System.out.println( "The stack is empty" );
    }

    if ( !( ls.isEmpty() ) )
    {
      ls.pop();
    }

    else
    {
      System.out.println( "The stack is empty" );
    }

    if ( !( ls.isEmpty() ) )
    {
      ls.pop();
    }

    else
    {
      System.out.println( "The stack is empty" );
    }

    if ( !( ls.isEmpty() ) )
    {
      ls.pop();
    }

    else
    {
      System.out.println( "The stack is empty" );
    }

    ls.push('a');

    Character input = new Character('a');
    Character input2 = new Character('b');

    if ( ls.contains(input) )
      System.out.println( "The character 'a' is in the stack." );

    else
      System.out.println( "The character 'a' is not in the stack." );

    if ( ls.contains(input2) )
      System.out.println( "The character 'b' is in the stack." );

    else
      System.out.println( "The character 'b' is not in the stack." );

  }// end of main

}// end of StackTester
