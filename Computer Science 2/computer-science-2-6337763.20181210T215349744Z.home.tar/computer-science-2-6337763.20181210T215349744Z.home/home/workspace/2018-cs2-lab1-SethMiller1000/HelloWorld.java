public class HelloWorld
{
	public static void main(String [] args)
	{
		System.out.println( "Hello World" );
		System.out.println();

		/// LOOP 1 ///

		int x = 9;

		do
		{
			System.out.print( x );
			x--;

		} while ( x > 0 ); // end of do while

		System.out.println();
		System.out.println();

		/// LOOP 2 ///

		int y = 2;

		while ( y < 8 )
		{
			System.out.print(y);

			if ( y != 7 )
			{
				System.out.print(" 0 ");

			} // end of if ( y != 7 )

			y++;

		} // end of while ( y < 7 )

		System.out.println();
		System.out.println();

		/// LOOP 3 ///

		for ( int i = 4; i < 29; i += 5 )
		{
			System.out.print(i);

			if ( i != 24 )
			{
				System.out.print(" ");

			} // end of if ( i != 24 )

		} // end of for ( int i = 4; i < 29; i + 5 )

		System.out.println();
		System.out.println();

		/// LOOP 4 ///
		int z = 111;

		while ( z > 103 )
		{
			System.out.print(z);

			if ( z != 103 )
			{
				System.out.print(" ");

			} // end of  if ( z != 103)

			z = z - 1;

		} // end of while ( z > 103 )

	} // end of main                  images/maximize@2x.png <=== File accidentally deleted

} // end of HelloWorld