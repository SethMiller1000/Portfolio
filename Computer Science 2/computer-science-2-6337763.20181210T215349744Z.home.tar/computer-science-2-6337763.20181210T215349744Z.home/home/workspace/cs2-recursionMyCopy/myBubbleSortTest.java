import java.util.Scanner;

public class myBubbleSortTest
{
  public static void main( String [] args )
  {
    Scanner scan = new Scanner( System.in );

    System.out.print( "Enter the size of the array: " );
    int size = scan.nextInt();
    System.out.println();

    int[] array = new int[size];

    for( int i = 0; i < size; i++ )
    {
      array[i] = size - i;
    }

    int[] result = BubbleSort.sort( array );
    System.out.println( result );

  }// end of main

}// end of myBubbleSortTest