import java.util.Scanner;

public class PostfixEvaluator
{
	public static boolean isOperand ( char c )
  {
    if( c >= '0' && c <= '9' )
    {
    	return true;

    }// end of if

    else
    {
      return false;

    }// end of else

  }// end of isOperand

  public static boolean isOperator ( char c )
  {
    return ( ( c == '+' ) || ( c == '-' ) || ( c == '*' ) || ( c == '/' ) );

  }// end of isOperator

  public static int charToInt( char c ) // Only works for 0 - 9
  {
  	if ( c == '0' )
  		return 0;

  	else if ( c == '1' )
  		return 1;

  	else if ( c == '2' )
  		return 2;

  	else if ( c == '3' )
  		return 3;

  	else if ( c == '4' )
  		return 4;

  	else if ( c == '5' )
  		return 5;

  	else if ( c == '6' )
  		return 6;

  	else if ( c == '7' )
  		return 7;

  	else if ( c == '8' )
  		return 8;

  	else
  		return 9;

  }// end of charToInt

  public static char intToChar( int c ) // Only works for 0 - 9
  {
  	if ( c == 0 )
  		return '0';

  	else if ( c == 1 )
  		return '1';

  	else if ( c == 2 )
  		return '2';

  	else if ( c == 3 )
  		return '3';

  	else if ( c == 4 )
  		return '4';

  	else if ( c == 5 )
  		return '5';

  	else if ( c == 6 )
  		return '6';

  	else if ( c == 7 )
  		return '7';

  	else if ( c == 8 )
  		return '8';

  	else
  		return '9';

  }// end of intToChar

	public static void main( String [] args )
	{
		int result = 0;
		CharStack evalStack = new CharStack();
		Scanner scan = new Scanner( System.in );

		System.out.print( "Please enter a postfix expression to evaluate: " );
		String input = scan.nextLine();

		for ( int i = 0; i < input.length(); i++ )
		{
			if ( isOperand( input.charAt(i) ) )
			{
				evalStack.push( input.charAt(i) );

			}// end of if ( input.charAt(i).isOperand() )

			else if ( isOperator( input.charAt(i) ) )
			{
				int operand2 = charToInt( evalStack.pop() );
				int operand1 = charToInt( evalStack.pop() );

				if ( input.charAt(i) == '+' )
				{
					result = operand1 + operand2;

				}// end of if ( input.charAt(i) == '+' )

				else if ( input.charAt(i) == '-' )
				{
					result = operand1 - operand2;

				}// end of else if ( input.charAt(i) == '-' )

				else if ( input.charAt(i) == '*' )
				{
					result = operand1 * operand2;

				}// end of else if ( input.charAt(i) == '*' )

				else if ( input.charAt(i) == '/' )
				{
					result = operand1 / operand2;

				}// end of else if ( input.charAt(i) == '/' )

				evalStack.push( intToChar( result ) );

			}// end of else if ( input.charAt(i).isOperator() )

		}// end of for ( int i = 0; i < input.length(); i++ )

		System.out.println();
		System.out.println( "Your postfix expression evaluates to: " + evalStack.pop() );

	}// end of main

}// end of PostfixEvaluator
