import java.util.Scanner;

public class CharStackTester
{
  public static void main(String [] args)
  {
    CharStack stack = new CharStack();

    // Test push

    if ( !( stack.isFull() ) )
    {
      stack.push ('a'); //stack = a
    }

    if ( !( stack.isFull() ) )
    {
      stack.push ('b'); //stack = ba
    }

    if ( !( stack.isFull() ) )
    {
      stack.push ('c'); //stack = cba
    }

    // Test peek and pop

    if ( !( stack.isEmpty() ) )
    {
      System.out.println( stack.peek() ); //shows c
      System.out.println( stack.pop() ); //shows c
      System.out.println();

    }// end of if !( stack.isEmpty() )

    if ( !( stack.isEmpty() ) )
    {
      System.out.println( stack.peek() ); //shows b
      System.out.println( stack.pop() ); //shows b
      System.out.println();

    }// end of if !( stack.isEmpty() )

    if ( !( stack.isEmpty() ) )
    {
      System.out.println( stack.peek() ); //shows a
      System.out.println( stack.pop() ); //shows a
      System.out.println();

    }// end of if !( stack.isEmpty() )

    // Test isEmpty
    if ( stack.isEmpty() )
    {
      System.out.println( "The stack is empty." );
      System.out.println();

    }// end of if ( stack.isEmpty() )

    else
    {
      System.out.println( "The stack is not empty." );
      System.out.println();

    }// end of else

    stack.push( 'z' ); // <== This is for testing both if statements.

    if ( stack.isEmpty() )
    {
      System.out.println( "The stack is empty." );
      System.out.println();

    }// end of if ( stack.isEmpty() )

    else
    {
      System.out.println( "The stack is not empty." );
      System.out.println();

    }// end of else

    // Test isFull

    stack.pop();

    while ( !(stack.isFull() ) )
    {
      stack.push('z');

    }// end of  while ( !(stack.isFull() ) )

    if ( stack.isFull() )
    {
      System.out.println( "The stack is full." );
      System.out.println();

    }// end of if ( stack.isFull() )

    else
    {
      System.out.println( "The stack is not full." );
      System.out.println();

    }// end of else

    // Test toString

    System.out.println( "The stack: " + stack );
    System.out.println();

    //// STEP 3 ////

    Scanner scan = new Scanner( System.in );
    System.out.println( "Please enter a parenthesized expression:" );
    String expression = scan.nextLine();
    System.out.println();

    CharStack stack2 = new CharStack();

    for ( int i = 0; i < expression.length(); i++ )
    {
      if ( expression.charAt( i ) == '(' )
      {
        stack2.push( expression.charAt( i ) );

      }// end of if ( expression.charAt( i ) == '(' )

      else if ( expression.charAt( i ) == ')' )
      {
        if ( !( stack2.isEmpty() ) )
        {
          stack2.pop();

        }// end of if !( stack2.isEmpty() )

        else
        {
          stack2.push( expression.charAt( i ) );

        }// end of else

      }// end of else if ( expression.charAt( i ) == ')' )

    }// end of for ( int i = 0; i < expression.length(); i++ )

    if ( stack2.isEmpty() )
    {
      System.out.println( "Your expression is balanced." );

    }// end of if ( stack2.isEmpty() )

    else
    {
      System.out.println( "Your expression is not balanced." );

    }// end of else

  }// end of main

}// end of CharStackTester
